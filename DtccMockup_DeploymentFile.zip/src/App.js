import logo from './logo.svg';
// import './App.css';
import Content from './Dashboard/Dashboard/Dashboard';
// import ContentUpdated from './Page3Upadted/ContentUpdated/ContentUpdated';
// // import Details from './Details/Details/Details';
// import ThirdNavigation from './ThirdNavigation/ThirdNavigation/ThirdNavigation';




function App() {
  return (
   
<Content/>
 
  );
}

export default App;
