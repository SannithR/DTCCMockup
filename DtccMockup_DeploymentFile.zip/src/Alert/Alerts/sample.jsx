import {Alerts} from './Alerts'

const Sample = () => {
  return <Alerts />
}
